
const STORAGE = "wt_v2_entries_v1";
function load(){ try{ return JSON.parse(localStorage.getItem(STORAGE)||'{}') }catch(e){return{}} }
function save(obj){ localStorage.setItem(STORAGE, JSON.stringify(obj)) }
let DB = load();
function getId(){ return Date.now() + Math.floor(Math.random()*1000) }
const el = id => document.getElementById(id);
function parseTimeToSeconds(hhmm){ if(!hhmm) return null; const parts = hhmm.split(':'); return parseInt(parts[0])*3600 + parseInt(parts[1])*60 }
function secondsToHHMM(s){ if(s==null) return "00:00"; const h=Math.floor(s/3600); const m=Math.floor((s%3600)/60); return String(h).padStart(2,'0')+":"+String(m).padStart(2,'0') }
function round2(n){ return Math.round(n*100)/100 }
el('calcBtn').addEventListener('click', ()=>{
  const date = el('date').value;
  const start = el('start').value;
  const end = el('end').value;
  const br = Number(el('break').value)||0;
  const rate = Number(el('rate').value)||0;
  if(!date || !start || !end){ alert('Add meg a dátumot, kezdést és végét.'); return; }
  let s = parseTimeToSeconds(start);
  let e = parseTimeToSeconds(end);
  if(e <= s) e += 24*3600;
  const durationSeconds = Math.max(0, e - s - br*60);
  const hours = round2(durationSeconds/3600);
  const amount = round2(hours * rate);
  el('timeShown').textContent = secondsToHHMM(durationSeconds);
  el('hoursShown').textContent = hours.toFixed(2);
  el('amountShown').textContent = amount.toFixed(2);
});
el('saveBtn').addEventListener('click', ()=>{
  const date = el('date').value;
  const start = el('start').value;
  const end = el('end').value;
  const br = Number(el('break').value)||0;
  const rate = Number(el('rate').value)||0;
  if(!date || !start || !end){ alert('Add meg a dátumot, kezdést és végét.'); return; }
  let s = parseTimeToSeconds(start);
  let e = parseTimeToSeconds(end);
  if(e <= s) e += 24*3600;
  const durationSeconds = Math.max(0, e - s - br*60);
  const hours = round2(durationSeconds/3600);
  const amount = round2(hours * rate);
  const id = getId();
  if(!DB[date]) DB[date] = [];
  DB[date].push({id, start, end, break:br, rate, durationSeconds, hours, amount});
  save(DB);
  alert('Elmentve.');
});
el('clearDay').addEventListener('click', ()=>{
  const date = el('date').value;
  if(!date) return alert('Válassz dátumot a törléshez.');
  if(!confirm('Tényleg törlöd a nap bejegyzéseit?')) return;
  delete DB[date];
  save(DB);
  alert('Törölve.');
});
el('showMonth').addEventListener('click', ()=>{
  const m = el('month').value;
  if(!m) return alert('Válassz hónapot.');
  renderMonth(m);
});
function renderMonth(month){
  const [y,mo] = month.split('-');
  const days = new Date(y, Number(mo), 0).getDate();
  let rows = '';
  let totalHours = 0; let totalAmount = 0; let entriesCount=0;
  for(let day=1; day<=days; day++){
    const key = `${y}-${String(mo).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const items = DB[key]||[];
    let start=''; let end=''; let br=0; let hrs=0; let amt=0; let rate='';
    if(items.length){
      entriesCount += items.length;
      items.forEach(it=>{ hrs += it.hours; amt += it.amount; rate = it.rate; br += it.break; });
      start = items[0].start; end = items[items.length-1].end;
    }
    totalHours += hrs; totalAmount += amt;
    rows += `<tr><td>${day}</td><td>${start||''}</td><td>${end||''}</td><td>${br||''}</td><td>${hrs?hrs.toFixed(2):''}</td><td>${rate?rate:''}</td><td>${amt?amt.toFixed(2):''}</td></tr>`;
  }
  const html = `<div class="card"><h3>Összesítő: ${month}</h3><div>Bejegyzések: ${entriesCount} &nbsp; Idő (óra): ${totalHours.toFixed(2)} &nbsp; Összeg: ${totalAmount.toFixed(2)}</div><table><thead><tr><th>Nap</th><th>Kezdés</th><th>Vége</th><th>Szünet</th><th>Idő (óra)</th><th>Óradíj</th><th>Összeg</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  el('summaryArea').innerHTML = html;
}
el('printBtn').addEventListener('click', ()=>{
  const month = el('month').value;
  if(!month) return alert('Válassz hónapot a nyomtatáshoz.');
  const content = el('summaryArea').innerHTML;
  if(!content) return alert('Nincs összesítő a megadott hónapra.');
  const w = window.open('', '_blank', 'width=800,height=900');
  const doc = `
  <html><head><meta charset="utf-8"><title>WorkTime ${month}</title>
  <style>
    body{font-family:Arial;margin:0;padding:0}
    .header{background:#f2c800;padding:16px;color:#000;font-weight:700}
    .foot{position:fixed;bottom:0;left:0;right:0;padding:12px;background:#f2c800}
    table{width:100%;border-collapse:collapse;margin-top:12px}
    th,td{border:1px solid #000;padding:6px;text-align:center}
    th{background:#f2c800}
  </style>
  </head><body>
    <div class="header">WorkTime — ${month}</div>
    <div>${content}</div>
    <div class="foot">https://dawedev38.github.io/</div>
  </body></html>`;
  w.document.write(doc);
  w.document.close();
  w.focus();
  setTimeout(()=>{ w.print(); }, 700);
});
el('exportCSV').addEventListener('click', ()=>{
  const month = el('month').value;
  if(!month) return alert('Válassz hónapot az exporthoz.');
  const [y,mo] = month.split('-');
  const days = new Date(y, Number(mo), 0).getDate();
  let lines = ['nap,kezdés,vége,szünet,óra,óradíj,összeg'];
  for(let day=1; day<=days; day++){
    const key = `${y}-${String(mo).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    const items = DB[key]||[];
    if(items.length){
      items.forEach(it=>{
        lines.push(`${day},${it.start},${it.end},${it.break},${it.hours.toFixed(2)},${it.rate},${it.amount.toFixed(2)}`);
      });
    }
  }
  const blob = new Blob([lines.join('\n')], {type:'text/csv;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download=`worktime_${month}.csv`; document.body.appendChild(a); a.click(); a.remove();
});
(function init(){ const now=new Date(); document.getElementById('month').value = now.toISOString().slice(0,7); document.getElementById('date').value = now.toISOString().slice(0,10); })();
