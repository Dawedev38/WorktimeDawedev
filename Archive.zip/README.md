# Worktime (PWA) — GitHub Pages telepítési útmutató (magyar)

Ez a csomag egy egyszerű, magyar nyelvű Worktime-szerű webapp (PWA), amit GitHub Pages-en tudsz hostolni, és iPhone-on Safari-ból hozzáadhatsz a kezdőképernyőhöz.

## Fájlok
- `index.html` — a webapp
- `manifest.json` — PWA manifest
- `service-worker.js` — offline cache
- `icon-192.png`, `icon-512.png` — alkalmazás ikonok
- `README.md` — ez az útmutató

## Gyors telepítés GitHub Pages-re
1. Hozz létre egy új GitHub repository-t (pl. `worktime-pwa`) — **public**.
2. Klónozd a repo-t vagy használd a GitHub webes feltöltést.
3. Tedd fel a fájlokat a repo gyökerébe, majd commit-olj.
4. GitHub weben: **Settings → Pages**.
   - Válaszd a **Branch: main** és **/ (root)** opciót, majd mentés.
   - Néhány perc múlva a site elérhető lesz: `https://<felhasználó>.github.io/<repo>/`
5. Nyisd meg a fenti URL-t iPhone Safari-ban.
6. Telepítés: Safari → Megosztás (Share) → **Hozzáadás a Kezdőképernyőhöz**.

> Megjegyzés: a Service Worker teljes funkcionalitása HTTPS alatt vagy `localhost`-on működik. GitHub Pages HTTPS-t biztosít.

## Személyre szabás
- Cseréld ki az `icon-192.png` és `icon-512.png` fájlokat saját ikonjaidra.
- Ha szeretnéd, készítek neked GitHub repo-t és feltöltöm ide az összes fájlt.

Ha szeretnéd, hogy én feltöltsem és beállítsam a GitHub Pages-t a repo-dra, add meg a GitHub felhasználónevedet (vagy adj repo hozzáférést), és elvégzem a lépéseket, illetve elküldöm a kész URL-t.
